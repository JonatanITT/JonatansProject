Linux router/firewall
==========================

This project is about setting up a linux router using iptables.

Techie stuff:
* OSPF and no NAT'ing
* debian linux for all machines
* iptables
* server exposes a webserver to the outside world
* ssh is limited to inside network only


Startup questions:
-----------------

1. how to approach this?
