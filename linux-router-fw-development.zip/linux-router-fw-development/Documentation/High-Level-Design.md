# ITS - Firewall Project High-Level-Design

## Introduction

The purpose of this exercise is to deliver a simple yet secure network that will employ both internal and external firewalls across all devices connected to the network

This exercise is aimed at creating a secure yet accessable fundenemental network that will lay the ground-work for future development & Implementation - we will aim to implement a series of security measures to deliver the most secure network we are capable of.

## Overview

The aim of this exercise is to construct a basic priliminary network that will serve as a vector to deploy & test firewalls. 

![High-Level Design Document](HLD-FW-PROJ.PNG)


### Device List & Naming Convention
As this exercise involves multiple groups the device list below is written dynamically where as X in the device names will corrispond to the number of the group, Laptop-x would mean Laptop-6 for memebers of Group-6.

#### Physical Machines
|Device Name|Device-Type|IP Address|LAN|Purpose|Comments| 
|---|---|---|---|---|---|
|Group-Laptop-X|Dynamic|?.?.?.?| ????| To provide a common | Serves as a bridge for the VMS|
||||||

#### Virtual Machines
This section will pertain to all virtualised devices that will exsist within a phyiscal host machine (as listed above) - as such 

|Device Name|Device-Type|IP Address|LAN|Purpose|Parent Device| 
|---|---|---|---|---|---|
|Webserver-X|Debian-9 Webserver|0.0.0.0/00|LAN NAME|To serve webpages|Group-Laptop-X|
|Host-X|Debian-9 Desktop|?.?.?.?|LAN NAME|For testing functionallity|Group-Laptop-X|
||||||


* System requirements
* Devices
* Where they exsist
* Why
* L3D
* Functionallity & Purpose

## Security & Privacy
* Devices
* Blocked Protocols
* Where the firewalls are located - what they are for
* Why we have internal firewalls aswell ass external

## Performance

## Hardware

This section describe what we have in the network topology.
#### TP-Link unmanaged 16 port

For this are we using a unmanaged 16 port TP-Link switch to connect all groups Firewalls and are connected to the internet
#### Firewall

The firewalls were running in every group are running on a "Debian" Linux machine to block and accept in and outgoing traffic.
#### VMWare

After the firewall do we have 2 Virtual machines, one webserver and one workstation.
The computer that are running the virtual machines is a laptop with the recommended requirements to run the virtual machines.

## Protocols and standards

### OSPF
Open shortest path first, is a routing protocol. It gathers information on links, then it constructs a topology and maps the network.
OSPF detects changes in the topology, like link failures, and finds a new route within seconds.

[OSPFv4 RFC 2328](https://www.ietf.org/rfc/rfc2328.txt)

### IPv4
Short for Internet Protocol version 4, which is a very common way of assigning IP addresses to Clients. It is written in dotted format and a typical IPv4
address could look like “192.168.1.6” the two last number are the most important in a network. the second number assigns the subnet IP, and the last number
assigns the client's address on a certain subnet Address Allocation documentation: Address Allocation

[IPv4 RFC 791](https://tools.ietf.org/html/rfc791)

### HTTP/HTTPS
Short for HyperText Protocol, is used for communication over the internet. It is a the application layer, which is a request/response protocol,
for example HTML files. HTTPS, is the same protocol as HTTP, only it has an added security features, which encrypts the text sent.

[HTTP RFC 2616](https://tools.ietf.org/html/rfc2616) 
[HTTPS RFC 2818](https://tools.ietf.org/html/rfc2818)

### TCP/IP
Is a suite of communication protocols, used to interconnect network devices on the internet. It can also be used on a private network.
It manages how messages are assembled and send in smaller packets and send across the internet, and the reassembled in the right order at,
the destination address. ICMP is a part of this protocol-suite. ICMP is a error reporting protocol, network devices like routers use to generate
error messages to the source IP when there is a problem with IP packet delivery.

[TCP RFC 793](https://tools.ietf.org/html/rfc793)
[IP RFC 791](https://tools.ietf.org/html/rfc791)

### DNS:

The DNS server is a database which contains public IP addresses with the associated hostnames. 
When entering a specific hostname into a web-browser, the DNS database converts the hostname into a IP address. The DNS server holds the IP addresses of the hostnames on the internet.

[DNS RFC 1034](https://tools.ietf.org/html/rfc1034)
[DNS RFC 1035](https://tools.ietf.org/html/rfc1035)

### IEEE 802
Family standard, that deals with LAN and MAN networks. The services and protocols specified in IEEE 802 map to the Data Link and Physical layer.
The most widely used standards are for the Ethernet family, Token Ring, Wireless LAN, Bridging and Virtual Bridged LANs.
[IEE802 Documentation](http://www.ieee802.org/)

### NTP:
Network time protocol synchronizes the clock between computer systems over packet-switched networks.
[IEE802 Documentation](https://www.ietf.org/rfc/rfc5905.txt)



## IP layout and VLANS
This section will contain the format in which each group will assign their machines IP addresses 
IP LAYOUT OF DESIGN

The format is followed...
X = (Group-Self defined number)

### Group.1 
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.1.10-19/24|10.0.1.0/24|172.16.1.x/32|192.168.1.10|

### Group.2 
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.2.20-29/24|10.0.2.0/24|172.16.2.x/32|192.168.1.20|

### Group 3
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.1.30-39/24|10.0.3.0/24|172.16.3.x/32|192.168.1.30|


### Group 4
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.1.40-49/24|10.0.4.0/24|172.16.4.x/32|192.168.1.40|


### Group 5
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.1.50-59/24|10.0.5.0/24|172.16.5x/32|192.168.1.50|

### Group 6
|Local Host|Inside Network|Loop-back|Gateway|
|---|---|---|---|---|
|192.168.1.60-69/24|10.0.6.0/24|172.16.6.x/32|192.168.1.60|

# Naming Convention
This section will pertain to the method and format in which we will name our devices - as such we have named them as ...

|NAME|Device Type|Comments|
|---|---|---|
|Host_x|	Laptop|		Each groups laptop to host the WS_x, SRV_x, Lan_x and Router_x|
|WS_x|		Debian|		Workstation w. Debian installed|
|SRV_x|		Debian|		Webserver w. Debian installed|
|Lan_x|		Subnet|		Connects WS_x and SRV_x on layer 2|
|Router_x|	Debian|		Debian Machine functioning as firewall/router.| 
|TP-Link|	SRX 240|		Connects Router_x from all the groups|
|SRX_A1	|	SRX 240|		Connects the TP-Link to the internet|